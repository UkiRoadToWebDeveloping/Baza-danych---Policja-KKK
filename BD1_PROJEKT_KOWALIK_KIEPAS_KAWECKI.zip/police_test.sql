-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Czas generowania: 30 Sty 2022, 00:00
-- Wersja serwera: 10.4.22-MariaDB
-- Wersja PHP: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Baza danych: `police_test`
--

DELIMITER $$
--
-- Procedury
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `Bron` ()  BEGIN
DECLARE koniec int default 0;
DECLARE imie_z varchar(20);
DECLARE nazwisko_z varchar(20);
DECLARE nazwa_z varchar(20);
DECLARE bron_cur CURSOR FOR SELECT osoby.imie, osoby.nazwisko, stopnie.nazwa FROM osoby, pracownicy, stopnie, administracja WHERE osoby.id_osoby=pracownicy.osoby_id_osoby AND pracownicy.stopnie_id_stopnie=stopnie.id_stopnie AND administracja.pracownicy_id_pracownicy=pracownicy.id_pracownicy AND (administracja.uprawnienia="Broń" OR administracja.uprawnienia="Broń + wgląd do ściśle tajnych akt" OR administracja.uprawnienia="Broń + wgląd do akt tajnych");
DECLARE CONTINUE HANDLER FOR NOT FOUND SET koniec=1;
DROP TEMPORARY TABLE IF EXISTS tmp; 
CREATE TEMPORARY TABLE tmp(
imie varchar(20),
nazwisko varchar(20),
nazwa varchar(20)
);
OPEN bron_cur;
petla: LOOP
FETCH bron_cur INTO imie_z, nazwisko_z, nazwa_z;
IF koniec = 1 THEN

LEAVE petla;
END IF;
INSERT INTO tmp VALUES (imie_z, nazwisko_z, nazwa_z);
END LOOP petla;
CLOSE bron_cur;
SELECT * FROM tmp;
DROP TEMPORARY TABLE IF EXISTS tmp; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `KartotekaProc` ()  BEGIN
DECLARE koniec int default 0;
DECLARE czas_z varchar(20);
DECLARE data_z date;
DECLARE kara_z varchar(40);
DECLARE odbyta_z tinyint(1);
DECLARE nazwa_z varchar(100);
DECLARE paragraf_z varchar(40);
DECLARE katoteka_cur CURSOR FOR SELECT kartoteka.czas_popelnienia, kartoteka.data_popelnienia, kartoteka.kara, kartoteka.odbyta, wykroczenia.nazwa, wykroczenia.paragraf FROM kartoteka, wykroczenia WHERE kartoteka.wykroczenia_id_wykroczenia=wykroczenia.id_wykroczenia;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET koniec=1;
DROP TEMPORARY TABLE IF EXISTS tmp; 
CREATE TEMPORARY TABLE tmp(
czas varchar(20),
data_p date,
kara varchar(40),
odbyta tinyint(1),
nazwa varchar(100),
paragraf varchar(40)
);
OPEN katoteka_cur;
petla: LOOP
FETCH katoteka_cur INTO czas_z, data_z, kara_z, odbyta_z, nazwa_z, paragraf_z;
IF koniec = 1 THEN

LEAVE petla;
END IF;
INSERT INTO tmp VALUES (czas_z, data_z, kara_z, odbyta_z, nazwa_z, paragraf_z);
END LOOP petla;
CLOSE katoteka_cur;
SELECT * FROM tmp;
DROP TEMPORARY TABLE IF EXISTS tmp; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `posterunki_areszt` ()  BEGIN
DECLARE koniec int default 0;
DECLARE nazwa_z varchar(20);
DECLARE adres_z varchar(40);
DECLARE miasto_z varchar(20);
DECLARE posterunki_cur CURSOR FOR SELECT posterunki.nazwa, posterunki.adres, miasta.nazwa FROM posterunki, miasta WHERE posterunki.miasta_id_miasta=miasta.id_miasta AND posterunki.areszt_id_areszt IS NOT NULL;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET koniec=1;
DROP TEMPORARY TABLE IF EXISTS tmp; 
CREATE TEMPORARY TABLE tmp(
nazwa varchar(20),
adres varchar(40),
miasto varchar(20)
);
OPEN posterunki_cur;
petla: LOOP
FETCH posterunki_cur INTO nazwa_z, adres_z, miasto_z;
IF koniec = 1 THEN
LEAVE petla;
END IF;
INSERT INTO tmp VALUES (nazwa_z, adres_z, miasto_z);
END LOOP petla;
CLOSE posterunki_cur;
SELECT * FROM tmp;
DROP TEMPORARY TABLE IF EXISTS tmp; 
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `Posterunkowi` ()  BEGIN
DECLARE koniec int default 0;
DECLARE imie_z varchar(20);
DECLARE nazwisko_z varchar(20);
DECLARE premia_z varchar(20);
DECLARE nazwa_z varchar(20);
DECLARE pensja_z varchar(20);
DECLARE posterunkowy_cur CURSOR FOR SELECT osoby.imie, osoby.nazwisko, pracownicy.premia, stopnie.nazwa, stopnie.pensja FROM osoby, pracownicy, stopnie WHERE osoby.id_osoby=pracownicy.osoby_id_osoby AND pracownicy.stopnie_id_stopnie=stopnie.id_stopnie AND stopnie.nazwa="Posterunkowy";
DECLARE CONTINUE HANDLER FOR NOT FOUND SET koniec=1;
DROP TEMPORARY TABLE IF EXISTS tmp; 
CREATE TEMPORARY TABLE tmp(
imie varchar(20),
nazwisko varchar(20),
premia varchar(20),
nazwa varchar(20),
pensja varchar(20)
);
OPEN posterunkowy_cur;
petla: LOOP
FETCH posterunkowy_cur INTO imie_z, nazwisko_z, premia_z, nazwa_z, pensja_z;
IF koniec = 1 THEN

LEAVE petla;
END IF;
INSERT INTO tmp VALUES (imie_z, nazwisko_z, premia_z, nazwa_z, pensja_z);
END LOOP petla;
CLOSE posterunkowy_cur;
SELECT * FROM tmp;

DROP TEMPORARY TABLE IF EXISTS tmp; 
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `administracja`
--

CREATE TABLE `administracja` (
  `id_administracja` int(11) NOT NULL,
  `uprawnienia` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `pracownicy_id_pracownicy` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `administracja`
--

INSERT INTO `administracja` (`id_administracja`, `uprawnienia`, `pracownicy_id_pracownicy`) VALUES
(17, 'Broń + wgląd do akt tajnych', 1),
(18, 'Broń', 2),
(19, 'Brak', 3),
(20, 'Broń + wgląd do ściśle tajnych akt', 4),
(21, 'Broń + wgląd do akt tajnych', 5),
(22, 'Broń + wgląd do akt tajnych', 6),
(23, 'Broń + wgląd do akt tajnych', 7),
(24, 'Brak', 8),
(25, 'Brak', 9),
(26, 'Brak', 10),
(27, 'Zezwolenie na wywiady', 11),
(28, 'Zezwolenie na wywiady', 12),
(29, 'Zezwolenie na wywiady', 13),
(30, 'Wgląd do wydatków i zarobków pracowników', 14),
(31, 'Wgląd do wydatków i zarobków pracowników', 15),
(32, 'uprawnienie', 6);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `areszt`
--

CREATE TABLE `areszt` (
  `id_areszt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `areszt`
--

INSERT INTO `areszt` (`id_areszt`) VALUES
(0),
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(17),
(18);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `cele`
--

CREATE TABLE `cele` (
  `id_cele` int(11) NOT NULL,
  `rozmiar` int(11) NOT NULL,
  `areszt_id_areszt` int(11) DEFAULT NULL,
  `wiezienia_id_wiezienia` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `cele`
--

INSERT INTO `cele` (`id_cele`, `rozmiar`, `areszt_id_areszt`, `wiezienia_id_wiezienia`) VALUES
(1, 3, 1, 3),
(2, 2, 2, 4),
(3, 5, 3, 3),
(4, 2, 3, 3),
(5, 3, 4, 4),
(6, 4, 5, 5),
(7, 3, 6, 6),
(8, 4, 7, 7),
(9, 3, 8, 8),
(10, 4, 9, 9),
(11, 2, 9, 9),
(12, 3, 10, 10),
(13, 3, 11, 11),
(14, 1, 11, 11),
(15, 5, 12, 13),
(16, 1, 14, 14),
(17, 2, 14, 14);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `kartoteka`
--

CREATE TABLE `kartoteka` (
  `id_kartoteka` int(11) NOT NULL,
  `czas_popelnienia` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `data_popelnienia` date NOT NULL,
  `kara` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `odbyta` tinyint(1) NOT NULL,
  `wykroczenia_id_wykroczenia` int(11) NOT NULL,
  `zatrzymani_id_zatrzymani` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `kartoteka`
--

INSERT INTO `kartoteka` (`id_kartoteka`, `czas_popelnienia`, `data_popelnienia`, `kara`, `odbyta`, `wykroczenia_id_wykroczenia`, `zatrzymani_id_zatrzymani`) VALUES
(1, '21:37', '2012-12-12', '25 lat więzienia', 0, 5, 1),
(2, '12:37', '2019-12-03', '5 lat więzienia', 0, 2, 2),
(3, '03:27', '2020-07-02', '10 lat więzienia', 0, 4, 3),
(4, '12:37', '0000-00-00', '3000 złoty grzywny', 1, 2, 4),
(5, '21:37', '2012-11-21', '2 miesiące więzienia', 1, 9, 6),
(6, '00:02', '2022-01-01', '5 lat więzienia', 0, 2, 7),
(7, '21:37', '2012-03-19', '2 miesiące więzienia', 1, 9, 8),
(8, '00:02', '2022-01-04', '5 lat więzienia', 0, 11, 9),
(9, '09:37', '2017-12-23', '5 miesiące więzienia', 1, 9, 10),
(10, '22:12', '2022-01-11', '5 lat więzienia', 0, 2, 11),
(11, '21:22', '2016-12-28', '24 miesiące więzienia', 1, 9, 12),
(12, '22:12', '2022-01-01', '15 lat więzienia', 0, 14, 13),
(13, '21:42', '2009-09-09', '20 000 złotych kary', 1, 13, 14),
(14, '22:10', '2022-01-13', '20 000 złotych kary', 1, 13, 15),
(15, '21:37', '2017-01-12', '17 lat pozbawienia wolnosci', 1, 7, 1);

--
-- Wyzwalacze `kartoteka`
--
DELIMITER $$
CREATE TRIGGER `data_p_trigger` BEFORE INSERT ON `kartoteka` FOR EACH ROW SET NEW.data_popelnienia=now()
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `kartoreka_trigger` BEFORE DELETE ON `kartoteka` FOR EACH ROW SIGNAL SQLSTATE VALUE '01000'
SET MESSAGE_TEXT = 'Nie mozna usunac nic z kartoteki'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `miasta`
--

CREATE TABLE `miasta` (
  `id_miasta` int(11) NOT NULL,
  `nazwa` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `wojewodztwo` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `powiat` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `gmina` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `kod_pocztowy` varchar(20) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `miasta`
--

INSERT INTO `miasta` (`id_miasta`, `nazwa`, `wojewodztwo`, `powiat`, `gmina`, `kod_pocztowy`) VALUES
(1, 'Kielce', 'swietokrzyskie', 'kielecki', 'Kielce', '25-009'),
(2, 'Radom', 'mazowieckie', 'radomski', 'Radom', '26-611'),
(3, 'Warszawa', 'mazowieckie', 'warszawski', 'Warszawa-Centrum', '00-119'),
(4, 'Lodz', 'lodzkie', 'lodzki', 'Lodz', '44-236'),
(5, 'Malbork', 'pomorskie', 'malborski', 'Malbork', '54-374'),
(6, 'Wroclaw', 'dolnoslaskie', 'wroclawski', 'Wroclaw', '21-233'),
(7, 'Opole', 'opolskie', 'opolski', 'Opole', '23-563'),
(8, 'Gdansk', 'pomorskie', 'gdanski', 'Gdansk', '88-253'),
(9, 'Gdynia', 'pomorskie', 'gdynski', 'Gdynia', '23-235'),
(10, 'Swinoujscie', 'zachodniopomorskie', 'Swinoujscie', 'Swinioujscie', '11-332'),
(11, 'Daleszyce', 'swietokszyskie', 'kielecki', 'Daleszyce', '13-422'),
(12, 'Zakopane', 'malopolskie', 'tatrzanski', 'Zakopane', '69-420'),
(13, 'Poznan', 'wielkopolskie', 'poznanski', 'Poznan', '15-468'),
(14, 'Sandomierz', 'swietokrzyskie', 'sandomierski', 'Sandomierz', '19-192'),
(15, 'Inowroclaw', 'kujawsko-pomorskie', 'inowroclawski', 'Inowroclaw', '42-142');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `osoby`
--

CREATE TABLE `osoby` (
  `id_osoby` int(11) NOT NULL,
  `imie` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `drugie_imie` varchar(20) COLLATE utf8_polish_ci DEFAULT NULL,
  `nazwisko` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `plec` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `nazwisko_panienskie` varchar(20) COLLATE utf8_polish_ci DEFAULT NULL,
  `wiek` int(11) NOT NULL,
  `pesel` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `adres` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `miasta_id_miasta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `osoby`
--

INSERT INTO `osoby` (`id_osoby`, `imie`, `drugie_imie`, `nazwisko`, `plec`, `nazwisko_panienskie`, `wiek`, `pesel`, `adres`, `miasta_id_miasta`) VALUES
(1, 'Andrzej', 'Tomasz', 'Wlodarczyk', 'M', '', 43, '93221365639', 'ul. Krawecka 32', 7),
(2, 'Agnieszka', '', 'Opatowicz', 'K', 'Pajak', 45, '34573857295', 'ul. Wolska 98', 6),
(3, 'Kamila', '', 'Kawelska', 'K', '', 32, '34582934064', 'ul. Siecka 2', 5),
(4, 'Tomasz', 'Joachim', 'Gruzinski', 'M', '', 54, '28465974729', 'ul. Morawska 82', 2),
(5, 'Dawid', '', 'Ryszardowicz', 'M', '', 19, '17593850283', 'ul. Lupska 32', 2),
(6, 'Daniel', 'Kamil', 'Poniedzielski', 'M', '', 23, '47586916253', 'ul. Murarska 56', 11),
(7, 'Barbara', 'Magda', 'Stawczyk', 'K', '', 23, '18593648572', 'ul. Liwecka 45', 8),
(8, 'Barnaba', 'Andrzej', 'Owalny', 'M', '', 26, '17483950163', 'ul. Prawska 867', 10),
(9, 'Lukasz', 'Tomasz', 'Kuda', 'M', '', 43, '16253748296', 'ul. Dluga 23', 10),
(10, 'Leon', 'Oskar', 'Paweron', 'M', '', 23, '17395847586', 'ul. Papieska 44', 11),
(11, 'Kamil', 'Pawel', 'Kauzinski', 'M', '', 57, '28574637584', 'ul. Jana Pawla II 54/7', 14),
(12, 'Pawel', 'Lukasz', 'Polakowicz', 'M', '', 45, '09758693657', 'ul. Parejska 76', 15),
(13, 'Dawid', 'Przemyslaw', 'Owalkiewicz', 'M', '', 34, '96857453657', 'ul. Szuwerska 87', 2),
(14, 'Kuba', '', 'Polaniec', 'M', '', 23, '87685763548', 'ul. Maruska 69', 3),
(15, 'Oskar', 'Leon', 'Lubuski', 'M', '', 41, '98475625365', 'ul. Micka 87', 4),
(16, 'Kuba', 'Pawel', 'Kula', 'M', '', 34, '36452756476', 'ul. Mielecka 65', 7),
(17, 'Dawid', 'Edward', 'Wilk', 'M', '', 23, '17463527598', 'ul. Rowaska 80', 8),
(18, 'Andrzej', 'Kuba', 'Duda', 'M', '', 21, '17586927685', 'ul. Ulidwa 46', 9),
(19, 'Maja', '', 'Panienska', 'K', '', 28, '98759879856', 'ul. Kaporska 28', 13),
(20, 'Magda', 'Marcelina', 'Markowicz', 'K', '', 38, '67676765483', 'ul. Ukraiska 5', 12),
(21, 'Mateusz', '', 'Kaleta', 'M', '', 29, '58889736592', 'ul. Pawelska 7', 2),
(22, 'Michal', '', 'Oparka', 'M', '', 45, '98758472667', 'ul. Murska 8', 1),
(23, 'Marcelina', 'Magda', 'Warkowiecka', 'K', '', 32, '98175888172', '', 3),
(24, 'Zuzanna', 'Paulina', 'Krakowska', 'K', '', 54, '99987364918', 'ul. Marcynska 456/87', 4),
(25, 'Kamil', 'Teresa', 'Elborski', 'M', '', 32, '65748672654', 'ul. Walecka 45', 3),
(26, 'Wanda', 'Paulina', 'Uma', 'K', '', 22, '11117666593', 'ul. Roska 34', 2),
(27, 'Piotr', 'Zbigniew', 'Adamczyk', 'M', '', 56, '00984659867', 'ul. Opalska 244', 12),
(28, 'Zbigniew', '', 'Ziobro', 'M', '', 34, '16448592852', 'ul. Dawelska 333', 11),
(29, 'Kamil', '', 'Warny', 'M', '', 23, '76574827564', 'ul. Szlicka 343', 10),
(30, 'Karolina', 'Katarzyna', 'Karpat', 'K', '', 76, '98746572854', 'ul. Paszolcka 25', 12),
(31, 'Lukasz', 'Kamil', 'Lugowski', 'M', '', 30, '55554434675', 'ul. Poznanska 75', 13),
(32, 'Oskar', '', 'Kamilski', 'M', '', 29, '87776354856', 'ul. Orwala 76', 14),
(33, 'Pawel', '', 'Werneta', 'M', '', 56, '11111866573', 'ul. Pawia 56', 15),
(34, 'Kuba', '', 'Iwanowicz', 'M', '', 34, '99876543219', 'ul. Lokdaska 12', 1),
(35, 'Roksana', '', 'Wegiel', 'K', '', 23, '00092700675', 'ul. Warka 45', 1),
(36, 'Karolina', 'Roksana', 'Opal', 'K', '', 45, '12648592645', 'ul. Kolejowa 98', 2),
(37, 'Sylwia', 'Wanda', 'Zaparty', 'K', '', 33, '96485736291', 'ul. Kraska 90', 4),
(38, 'Grzegorz', '', 'Ryszynski', 'M', '', 44, '86466673821', 'ul. Panienska 8', 5),
(39, 'Edward', '', 'Tareta', 'M', '', 58, '22274536852', 'ul. Polska 12', 9),
(40, 'Emilia', '', 'Kamien', 'K', '', 29, '98654398765', 'ul. Jana Pawla II 54', 6),
(41, 'Krystyna', '', 'Zak', 'K', '', 60, '86745839621', 'ul. Krawecka 67', 1),
(42, 'Jaroslaw', '', 'Kaczynski', 'M', '', 72, '98657463863', 'ul. Kaskieksa 66', 2),
(43, 'Andrzej', 'Ludwik', 'Labecki', 'M', '', 65, '98264103845', 'ul. Trzysta 81', 7),
(44, 'Zbigniew', 'Jaroslaw', 'Orato', 'M', '', 33, '18746356777', 'ul. Lapiecka 20', 6),
(45, 'Paulina', '', 'Sitek', 'K', '', 28, '98123456789', 'ul. Okrawna 9/9', 3);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `posterunki`
--

CREATE TABLE `posterunki` (
  `id_posterunki` int(11) NOT NULL,
  `nazwa` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `adres` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `koszty_miesiac` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `przychody_miesiac` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `miasta_id_miasta` int(11) NOT NULL,
  `areszt_id_areszt` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `posterunki`
--

INSERT INTO `posterunki` (`id_posterunki`, `nazwa`, `adres`, `koszty_miesiac`, `przychody_miesiac`, `miasta_id_miasta`, `areszt_id_areszt`) VALUES
(1, 'Posterunek 001', 'ul. Krakowska 33', '13000', '14500', 1, 1),
(2, 'Posterunek 002', 'ul. Konwalii 23', '14000', '24000', 2, 2),
(3, 'Posterunek 003', 'ul. Placowa 53', '11000', '14500', 3, 3),
(4, 'Posterunek 004', 'ul. Szesnasta 55', '11000', '14500', 4, NULL),
(5, 'Posterunek 005', 'ul. Kaminska 64', '12000', '14500', 5, NULL),
(6, 'Posterunek 006', 'ul. Bramowa 3', '23000', '14500', 6, 4),
(7, 'Posterunek 007', 'ul. Janowa 4', '15000', '14500', 7, 5),
(8, 'Posterunek 009', 'ul. Kawowa 53', '17000', '14500', 8, 6),
(9, 'Posterunek 010', 'ul. Sowa 1', '18000', '14500', 9, 7),
(10, 'Posterunek 011', 'ul. Jana Pawla II 45', '19000', '14500', 10, 8),
(11, 'Posterunek 021', 'ul. Polska 77', '12000', '15500', 11, 9),
(12, 'Posterunek 031', 'ul. Owalna 23', '12000', '14500', 12, 10),
(13, 'Posterunek 045', 'ul. Szarecka 37', '11000', '14500', 13, 11),
(14, 'Posterunek 065', 'ul. Kminska 77', '13000', '14500', 14, 12),
(15, 'Posterunek 101', 'ul. Angielska 102', '13600', '14500', 15, NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `pracownicy`
--

CREATE TABLE `pracownicy` (
  `id_pracownicy` int(11) NOT NULL,
  `premia` varchar(20) COLLATE utf8_polish_ci DEFAULT NULL,
  `czas_pracy` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `zezwolenie_na_bron` tinyint(1) NOT NULL,
  `dyzury` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `osoby_id_osoby` int(11) NOT NULL,
  `stopnie_id_stopnie` int(11) NOT NULL,
  `posterunki_id_posterunki` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `pracownicy`
--

INSERT INTO `pracownicy` (`id_pracownicy`, `premia`, `czas_pracy`, `zezwolenie_na_bron`, `dyzury`, `osoby_id_osoby`, `stopnie_id_stopnie`, `posterunki_id_posterunki`) VALUES
(1, '1000 PLN', '200H', 1, 'PATROL NOCNY - SWIĘTA', 1, 5, 1),
(2, '200 PLN', '180H', 1, 'NOCNE CZUWANIE', 2, 2, 2),
(3, 'BRAK', '160H', 1, 'BRAK', 3, 4, 3),
(4, 'BRAK', '160H', 1, 'BRAK', 4, 1, 4),
(5, 'BRAK', '160H', 1, 'BRAK', 5, 1, 5),
(6, 'BRAK', '160H', 1, 'BRAK', 6, 1, 6),
(7, 'BRAK', '160H', 1, 'BRAK', 7, 1, 7),
(8, '1500 PLN', '260H', 1, 'NOCNE CZUWANIE', 8, 8, 8),
(9, 'BRAK', '160H', 0, 'BRAK', 9, 9, 9),
(10, 'BRAK', '160H', 0, 'BRAK', 10, 10, 10),
(11, 'BRAK', '160H', 1, 'BRAK', 11, 15, 11),
(12, 'BRAK', '160H', 0, 'BRAK', 12, 1, 12),
(13, 'BRAK', '160H', 1, 'BRAK', 13, 1, 13),
(14, 'BRAK', '160H', 1, 'BRAK', 14, 2, 14),
(15, 'BRAK', '160H', 1, 'BRAK', 15, 2, 15);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `stopnie`
--

CREATE TABLE `stopnie` (
  `id_stopnie` int(11) NOT NULL,
  `nazwa` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `korpus` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `pensja` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `awans` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `stopnie`
--

INSERT INTO `stopnie` (`id_stopnie`, `nazwa`, `korpus`, `pensja`, `awans`) VALUES
(1, 'Posterunkowy', 'Szeregowych Policji', '2000', 1),
(2, 'Starszy Posterunkowy', 'Szeregowych Policji', '2200', 1),
(3, 'Sierzant', 'Podoficerow Policji', '2500', 1),
(4, 'Starszy Sierzant', 'Podoficerow Policji', '2700', 1),
(5, 'Sierzant Sztabowy', 'Podoficerow Policji', '3100', 1),
(6, 'Mlodszy Aspirant', 'Aspirantow Policji', '3300', 1),
(7, 'Aspirant', 'Aspirantow Policji', '3600', 1),
(8, 'Starszy Aspirant', 'Aspirantow Policji', '3800', 1),
(9, 'Aspirant Sztabowy', 'Aspirantow Policji', '4000', 1),
(10, 'Podkomisarz', 'Oficerow Mlodszych Policji', '4200', 1),
(11, 'Komisarz', 'Oficerow Mlodszych Policji', '4400', 1),
(12, 'Nadkomisarz', 'Oficerow Mlodszych Policji', '4700', 1),
(13, 'Podinspektor', 'Oficerow Starszych Policji', '5000', 1),
(14, 'Mlodszy Inspektor', 'Oficerow Starszych Policji', '5300', 1),
(15, 'Inspektor', 'Oficerow Starszych Policji', '5600', 1),
(16, 'Nadinspektor', 'Generalow Policji', '6000', 1),
(17, 'Generalny Inspektor', 'Generalow Policji', '6600', 0);

--
-- Wyzwalacze `stopnie`
--
DELIMITER $$
CREATE TRIGGER `stopnie_trigger` BEFORE INSERT ON `stopnie` FOR EACH ROW SIGNAL SQLSTATE VALUE '01000'
SET MESSAGE_TEXT = 'Nie mozna dodac nowego stopnia'
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wiezienia`
--

CREATE TABLE `wiezienia` (
  `id_wiezienia` int(11) NOT NULL,
  `nazwa` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `adres` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `typ` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `miasta_id_miasta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `wiezienia`
--

INSERT INTO `wiezienia` (`id_wiezienia`, `nazwa`, `adres`, `typ`, `miasta_id_miasta`) VALUES
(3, 'Więzienie nr 123', 'ul.JP2 15', 'Podstawowy', 1),
(4, 'Więzienie nr 90', 'ul.Bohaterów War. 32', 'Podstawowy', 2),
(5, 'Więzienie nr 25', 'ul.Jana 5', 'Podstawowy', 3),
(6, 'Więzienie nr 32', 'ul.Marka 5', 'Podstawowy', 4),
(7, 'Więzienie nr 40', 'ul.Pawła 5', 'Podstawowy', 5),
(8, 'Więzienie nr 5', 'ul.Wojtka 5', 'Podstawowy', 6),
(9, 'Więzienie nr 2', 'ul.Krańcowa 5', 'Podstawowy', 7),
(10, 'Więzienie nr 122', 'ul.Mieszała 20', 'Podstawowy', 8),
(11, 'Więzienie nr 12', 'ul.Graniczna 20', 'Podstawowy', 9),
(12, 'Więzienie nr 115', 'ul.Graniczna  20', 'Podstawowy', 10),
(13, 'Więzienie nr 55', 'ul. Roberta  20', 'Podstawowy', 11),
(14, 'Więzienie nr 5', 'ul.Lewandowski 20', 'Podstawowy', 12),
(15, 'Więzienie nr 39', 'ul.Sousa 20', 'Podstawowy', 13),
(16, 'Więzienie nr 29', 'ul.Mireckiego 20', 'Podstawowy', 14),
(17, 'Więzienie nr 19', 'ul.Słonia 20', 'Podstawowy', 15);

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `wykroczenia`
--

CREATE TABLE `wykroczenia` (
  `id_wykroczenia` int(11) NOT NULL,
  `nazwa` varchar(100) COLLATE utf8_polish_ci NOT NULL,
  `paragraf` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `kara_min` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `kara_max` varchar(40) COLLATE utf8_polish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `wykroczenia`
--

INSERT INTO `wykroczenia` (`id_wykroczenia`, `nazwa`, `paragraf`, `kara_min`, `kara_max`) VALUES
(1, 'Zebranie', 'KW Art. 58. § 1', 'nagana', 'ograniczenie wolnosci'),
(2, 'Nielegalne prowadzenie dzialalnosci gospodarczej', 'KW Art. 60^1. § 1', 'grzywna', 'ograniczenie wolnosci'),
(3, 'Umieszczanie plakatow bez zezwolenia', 'KW Art. 63a. § 1', 'grzywna', 'ograniczenie wolnosci'),
(4, 'Oszukiwanie organu legitymujacego', 'KW Art. 65. § 1', 'grzywna', 'ograniczenie wolnosci'),
(5, 'Usuwanie ogloszenia panstwowego', 'KW Art. 67. § 1', 'grzywna', 'areszt'),
(6, 'Falszowanie symboli panstwowych', 'KW Art. 68. § 1', 'grzywna', 'grzywna'),
(7, 'Zabicie czlowieka', 'KK Art. 148. § 1', '8 lat pozbawienia wolnosci', 'dozywotnie pozbawienie wolnosci'),
(8, 'Dewastacja srodowiska naturalnego', 'KK Art. 181. § 1', '3 miesiace pozbawienia wolnosci', '5 lat pozbawienia wolnosci'),
(9, 'Zanieczyszczanie srodowiska', 'KK Art. 182. § 1', '3 miesiace pozbawienia wolnosci', '5 lat pozbawienia wolnosci'),
(10, 'Pozbawianie człowieka wolności', 'KK Art. 189. § 1', '3 miesiace pozbawienia wolnosci', '5 lat pozbawienia wolnosci'),
(11, 'Handel ludzmi', 'KK Art. 189a. § 1', '3 lata pozbawienia wolnosci', 'dozywotnie pozbawienie wolnosci'),
(12, 'Obrazenie uczuc religijnych', 'KK Art. 196', 'grzywna', '2 lata pozbawienia wolnosci'),
(13, 'Napasc seksualna', 'KK Art. 197. § 1', '2 lata pozbawienia wolnosci', '12 lat pozbawienia wolnosci'),
(14, 'Dostaraczanie alkoholu maloletnim', 'KK Art. 208', 'grzywna', '2 lata pozbawienia wolnosci'),
(15, 'Publiczna obraza', 'KK Art. 216. § 1', 'grzywna', 'ograniczenie wolnosci');

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `zatrzymani`
--

CREATE TABLE `zatrzymani` (
  `id_zatrzymani` int(11) NOT NULL,
  `powod` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `kara` varchar(40) COLLATE utf8_polish_ci DEFAULT NULL,
  `znaki_szczegolne` varchar(100) COLLATE utf8_polish_ci DEFAULT NULL,
  `notowany` tinyint(1) NOT NULL,
  `cele_id_cele` int(11) DEFAULT NULL,
  `osoby_id_osoby` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Zrzut danych tabeli `zatrzymani`
--

INSERT INTO `zatrzymani` (`id_zatrzymani`, `powod`, `kara`, `znaki_szczegolne`, `notowany`, `cele_id_cele`, `osoby_id_osoby`) VALUES
(1, 'Strzelanina', '5 LAT', 'BRAK', 1, 1, 1),
(2, 'Kradziez', '2 LATa', 'Kobra na szyi', 1, 2, 2),
(3, 'Narkotyki', '5 LAT', 'Łezka pod okiem', 1, 3, 3),
(4, 'Narkotyki', '3 miesiące ', 'BRAK', 1, 4, 4),
(5, 'Narkotyki', '5000 złoty ', 'BRAK', 1, 5, 5),
(6, 'Narkotyki', '1000 złoty ', 'BRAK', 1, 6, 6),
(7, 'Narkotyki', ' 1 miesiąc', 'BRAK', 1, 7, 7),
(8, 'Narkotyki', ' 14 dni ', 'Blizna pod okiem', 1, 8, 8),
(9, 'Narkotyki', '15 dni ', 'BRAK', 1, 9, 9),
(10, 'Narkotyki', ' 3 Lata', 'BRAK', 1, 10, 10),
(11, 'Narkotyki', ' 5 LAT', 'Brak 4 palców', 1, 11, 11),
(12, 'Narkotyki', ' 14 miesięcy', 'BRAK', 1, 12, 12),
(13, 'Narkotyki', ' 5 miesięcy', 'BRAK', 1, 13, 13),
(14, 'Narkotyki', '5000 złoty ', 'BRAK', 1, 14, 14),
(15, 'Narkotyki', ' 1000 złoty', 'BRAK', 1, 15, 15);

--
-- Indeksy dla zrzutów tabel
--

--
-- Indeksy dla tabeli `administracja`
--
ALTER TABLE `administracja`
  ADD PRIMARY KEY (`id_administracja`),
  ADD KEY `pracownicy_administracja` (`pracownicy_id_pracownicy`);

--
-- Indeksy dla tabeli `areszt`
--
ALTER TABLE `areszt`
  ADD PRIMARY KEY (`id_areszt`);

--
-- Indeksy dla tabeli `cele`
--
ALTER TABLE `cele`
  ADD PRIMARY KEY (`id_cele`),
  ADD KEY `wiezienia_cele` (`wiezienia_id_wiezienia`),
  ADD KEY `areszt_cele` (`areszt_id_areszt`);

--
-- Indeksy dla tabeli `kartoteka`
--
ALTER TABLE `kartoteka`
  ADD PRIMARY KEY (`id_kartoteka`),
  ADD KEY `zatrzymani_kartoteka` (`zatrzymani_id_zatrzymani`),
  ADD KEY `wykroczenia_kartoteka` (`wykroczenia_id_wykroczenia`);

--
-- Indeksy dla tabeli `miasta`
--
ALTER TABLE `miasta`
  ADD PRIMARY KEY (`id_miasta`);

--
-- Indeksy dla tabeli `osoby`
--
ALTER TABLE `osoby`
  ADD PRIMARY KEY (`id_osoby`),
  ADD KEY `miasta_osoby` (`miasta_id_miasta`);

--
-- Indeksy dla tabeli `posterunki`
--
ALTER TABLE `posterunki`
  ADD PRIMARY KEY (`id_posterunki`),
  ADD KEY `miasta_posterunki` (`miasta_id_miasta`),
  ADD KEY `areszt_posterunki` (`areszt_id_areszt`);

--
-- Indeksy dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD PRIMARY KEY (`id_pracownicy`),
  ADD KEY `stopnie_pracownicy` (`stopnie_id_stopnie`),
  ADD KEY `osoby_pracownicy` (`osoby_id_osoby`),
  ADD KEY `posterunki_pracownicy` (`posterunki_id_posterunki`);

--
-- Indeksy dla tabeli `stopnie`
--
ALTER TABLE `stopnie`
  ADD PRIMARY KEY (`id_stopnie`);

--
-- Indeksy dla tabeli `wiezienia`
--
ALTER TABLE `wiezienia`
  ADD PRIMARY KEY (`id_wiezienia`),
  ADD KEY `wiezienia_miasta` (`miasta_id_miasta`);

--
-- Indeksy dla tabeli `wykroczenia`
--
ALTER TABLE `wykroczenia`
  ADD PRIMARY KEY (`id_wykroczenia`);

--
-- Indeksy dla tabeli `zatrzymani`
--
ALTER TABLE `zatrzymani`
  ADD PRIMARY KEY (`id_zatrzymani`),
  ADD KEY `cele_zatrzymani` (`cele_id_cele`),
  ADD KEY `osoby_zatrzymani` (`osoby_id_osoby`);

--
-- AUTO_INCREMENT dla zrzuconych tabel
--

--
-- AUTO_INCREMENT dla tabeli `administracja`
--
ALTER TABLE `administracja`
  MODIFY `id_administracja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT dla tabeli `kartoteka`
--
ALTER TABLE `kartoteka`
  MODIFY `id_kartoteka` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `miasta`
--
ALTER TABLE `miasta`
  MODIFY `id_miasta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `osoby`
--
ALTER TABLE `osoby`
  MODIFY `id_osoby` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT dla tabeli `posterunki`
--
ALTER TABLE `posterunki`
  MODIFY `id_posterunki` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  MODIFY `id_pracownicy` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `stopnie`
--
ALTER TABLE `stopnie`
  MODIFY `id_stopnie` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT dla tabeli `wiezienia`
--
ALTER TABLE `wiezienia`
  MODIFY `id_wiezienia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT dla tabeli `wykroczenia`
--
ALTER TABLE `wykroczenia`
  MODIFY `id_wykroczenia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT dla tabeli `zatrzymani`
--
ALTER TABLE `zatrzymani`
  MODIFY `id_zatrzymani` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `administracja`
--
ALTER TABLE `administracja`
  ADD CONSTRAINT `pracownicy_administracja` FOREIGN KEY (`pracownicy_id_pracownicy`) REFERENCES `pracownicy` (`id_pracownicy`);

--
-- Ograniczenia dla tabeli `cele`
--
ALTER TABLE `cele`
  ADD CONSTRAINT `areszt_cele` FOREIGN KEY (`areszt_id_areszt`) REFERENCES `areszt` (`id_areszt`),
  ADD CONSTRAINT `wiezienia_cele` FOREIGN KEY (`wiezienia_id_wiezienia`) REFERENCES `wiezienia` (`id_wiezienia`);

--
-- Ograniczenia dla tabeli `kartoteka`
--
ALTER TABLE `kartoteka`
  ADD CONSTRAINT `wykroczenia_kartoteka` FOREIGN KEY (`wykroczenia_id_wykroczenia`) REFERENCES `wykroczenia` (`id_wykroczenia`),
  ADD CONSTRAINT `zatrzymani_kartoteka` FOREIGN KEY (`zatrzymani_id_zatrzymani`) REFERENCES `zatrzymani` (`id_zatrzymani`);

--
-- Ograniczenia dla tabeli `osoby`
--
ALTER TABLE `osoby`
  ADD CONSTRAINT `miasta_osoby` FOREIGN KEY (`miasta_id_miasta`) REFERENCES `miasta` (`id_miasta`);

--
-- Ograniczenia dla tabeli `posterunki`
--
ALTER TABLE `posterunki`
  ADD CONSTRAINT `areszt_posterunki` FOREIGN KEY (`areszt_id_areszt`) REFERENCES `areszt` (`id_areszt`),
  ADD CONSTRAINT `miasta_posterunki` FOREIGN KEY (`miasta_id_miasta`) REFERENCES `miasta` (`id_miasta`);

--
-- Ograniczenia dla tabeli `pracownicy`
--
ALTER TABLE `pracownicy`
  ADD CONSTRAINT `osoby_pracownicy` FOREIGN KEY (`osoby_id_osoby`) REFERENCES `osoby` (`id_osoby`),
  ADD CONSTRAINT `posterunki_pracownicy` FOREIGN KEY (`posterunki_id_posterunki`) REFERENCES `posterunki` (`id_posterunki`),
  ADD CONSTRAINT `stopnie_pracownicy` FOREIGN KEY (`stopnie_id_stopnie`) REFERENCES `stopnie` (`id_stopnie`);

--
-- Ograniczenia dla tabeli `wiezienia`
--
ALTER TABLE `wiezienia`
  ADD CONSTRAINT `wiezienia_miasta` FOREIGN KEY (`miasta_id_miasta`) REFERENCES `miasta` (`id_miasta`);

--
-- Ograniczenia dla tabeli `zatrzymani`
--
ALTER TABLE `zatrzymani`
  ADD CONSTRAINT `cele_zatrzymani` FOREIGN KEY (`cele_id_cele`) REFERENCES `cele` (`id_cele`),
  ADD CONSTRAINT `osoby_zatrzymani` FOREIGN KEY (`osoby_id_osoby`) REFERENCES `osoby` (`id_osoby`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
